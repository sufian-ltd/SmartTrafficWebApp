<h1 align="center" style="color: #fff;font-family: serif;">
    ! Smart Traffic Web App Panel !</h1>
<nav class="navbar navbar-inverse container-fluid"
     style="font-size: 21px; background: #000077; font-family: serif;font: bold;">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header" style="color: #543534">
            <button type="button" class="navbar-toggle collapsed"
                    data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"
                    aria-expanded="false">
                <span class="sr-only">Toggle navigation</span> <span
                    class="icon-bar"></span> <span class="icon-bar"></span> <span
                    class="icon-bar"></span>
            </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse"
             id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav container">
                <li><a href="index.php" class="active" style="font-size: 24px;color: #fff;">Smart Traffic App</a></li>
                <li><a href="thana.php" class="active">Home</a></li>
                <li><a href="thana-case.php">Case List</a></li>
                <li><a href="thana-logout.php">Logout</a></li>
            </ul>

        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav>
